﻿using System;
using System.Collections.Generic;

namespace WebApp.Models.Movies;

public partial class LanguageRole
{
    public int RoleId { get; set; }

    public string? LanguageRole1 { get; set; }
}
