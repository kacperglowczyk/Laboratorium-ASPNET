﻿using System;
using System.Collections.Generic;

namespace WebApp.Models.Movies;

public partial class ProductionCompany
{
    public int CompanyId { get; set; }

    public string? CompanyName { get; set; }
}
