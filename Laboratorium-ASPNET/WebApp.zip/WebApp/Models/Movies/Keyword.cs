﻿using System;
using System.Collections.Generic;

namespace WebApp.Models.Movies;

public partial class Keyword
{
    public int KeywordId { get; set; }

    public string? KeywordName { get; set; }
}
